// ==========================================
// AI-Hub Market 完整服务器
// 支持多AI协作任务分发系统
// ==========================================
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const app = express();
const PORT = 3001;

// ==========================================
// 配置
// ==========================================
const DEEPSEEK_API_KEY = "sk-aa2e775113174aacadc873c81e732f8f";

const API_KEYS_FILE = path.join(__dirname, 'data', 'api_keys.json');
const SCORES_FILE = path.join(__dirname, 'data', 'ai_scores.json');

// 确保data文件夹存在
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'));
}

// ==========================================
// 数据读取/保存函数
// ==========================================
function readJsonFile(filePath, defaultData) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return defaultData;
    } catch (error) {
        console.error(`读取文件失败 ${filePath}:`, error);
        return defaultData;
    }
}

// ==========================================
// 辅助函数：按评分分配最佳 AI 提供商
// ==========================================
function assignBestProviderByScore(subtasks) {
    // 读取评分数据
    const scoresData = readJsonFile(SCORES_FILE, { ai_scores: [] });

    // 每个 AI 类型可用的提供商
    const typeProviders = {
        '视觉': ['openai', 'google'],
        '图像': ['openai', 'google'],
        '文字': ['openai', 'anthropic', 'google', 'deepseek'],
        '语言': ['openai', 'anthropic', 'google', 'deepseek'],
        '音频': ['google'],
        '视频': ['google'],
        '数据分析': ['openai', 'anthropic', 'google', 'deepseek']
    };

    // 提供商到模型的映射
    const providerModelMap = {
        'openai': 'gpt-4o',
        'anthropic': 'claude-3-sonnet-20240229',
        'google': 'gemini-pro',
        'deepseek': 'deepseek-chat'
    };

    // 构建评分查找表
    const scoreMap = {};
    scoresData.ai_scores.forEach(ai => {
        scoreMap[ai.type] = scoreMap[ai.type] || {};
        scoreMap[ai.type][ai.id] = {
            avgScore: parseFloat(ai.avgScore) || 0,
            ratingCount: ai.ratingCount || 0
        };
    });

    console.log("📊 评分数据:", scoreMap);

    // 为每个子任务分配评分最高的提供商
    return subtasks.map(subtask => {
        const availableProviders = typeProviders[subtask.type] || ['deepseek'];

        // 找出评分最高的提供商
        let bestProvider = availableProviders[0];
        let bestScore = -1;
        let bestRatingCount = 0;

        for (const provider of availableProviders) {
            const providerScore = scoreMap[subtask.type]?.[provider]?.avgScore || 0;
            const providerRatingCount = scoreMap[subtask.type]?.[provider]?.ratingCount || 0;

            // 按评分排序，评分相同时按评分次数排序
            if (providerScore > bestScore || (providerScore === bestScore && providerRatingCount > bestRatingCount)) {
                bestProvider = provider;
                bestScore = providerScore;
                bestRatingCount = providerRatingCount;
            }
        }

        console.log(`🎯 ${subtask.type} -> ${bestProvider} (评分: ${bestScore})`);

        return {
            ...subtask,
            aiProvider: bestProvider,
            aiModel: providerModelMap[bestProvider] || subtask.aiModel,
            aiScore: bestScore  // 添加评分信息供前端显示
        };
    });
}

// ==========================================
// 子任务解析备用函数
// ==========================================
function parseSubtasksFallback(aiSuggestion, aiTypes) {
    const subtasks = [];
    const providerMap = {
        '视觉': 'openai',
        '文字': 'openai',
        '语言': 'anthropic',
        '图像': 'openai',
        '音频': 'google',
        '视频': 'google',
        '数据分析': 'openai'
    };

    const modelMap = {
        '视觉': 'gpt-4o-vision-preview',
        '文字': 'gpt-4o',
        '语言': 'claude-3-sonnet-20240229',
        '图像': 'gpt-4o-vision-preview',
        '音频': 'gemini-pro',
        '视频': 'gemini-pro',
        '数据分析': 'gpt-4o'
    };

    aiTypes.forEach((type, index) => {
        const description = extractContextFromSuggestion(aiSuggestion, type);
        subtasks.push({
            id: `subtask_${index}`,
            type: type,
            aiProvider: providerMap[type] || 'deepseek',
            aiModel: modelMap[type] || 'deepseek-chat',
            prompt: description || `请完成以下${type}任务：根据"${aiSuggestion.substring(0, 100)}..."进行相关创作`
        });
    });

    return subtasks;
}

// 从建议中提取相关描述
function extractContextFromSuggestion(suggestion, type) {
    const keywords = {
        '视觉': ['设计', '图片', '海报', '图标', 'logo', '视觉效果', '配色', '布局'],
        '文字': ['撰写', '文案', '标题', '描述', '内容', '文字', '文章'],
        '语言': ['翻译', '校对', '润色', '语言', '文本'],
        '图像': ['生成', '创建', '制作', '图像', '绘图', '画'],
        '音频': ['生成', '创作', '音频', '声音', '音效', '配音', 'BGM'],
        '视频': ['制作', '剪辑', '视频', '动画', '渲染', '特效'],
        '数据分析': ['分析', '统计', '图表', '数据', '可视化', '趋势']
    };

    const typeKeywords = keywords[type] || [];
    for (const keyword of typeKeywords) {
        if (suggestion.toLowerCase().includes(keyword.toLowerCase())) {
            const index = suggestion.toLowerCase().indexOf(keyword.toLowerCase());
            const start = Math.max(0, index - 30);
            const end = Math.min(suggestion.length, index + 70);
            return suggestion.substring(start, end).trim();
        }
    }

    return null;
}

function saveJsonFile(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error(`保存文件失败 ${filePath}:`, error);
        return false;
    }
}

// ==========================================
// AI 服务商适配器
// ==========================================
const AI_PROVIDERS = {
    openai: {
        name: 'OpenAI',
        call: async (model, prompt, apiKey) => {
            const response = await axios.post(
                'https://api.openai.com/v1/chat/completions',
                {
                    model: model,
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.7
                },
                {
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            return response.data.choices[0].message.content;
        }
    },
    anthropic: {
        name: 'Anthropic',
        call: async (model, prompt, apiKey) => {
            const response = await axios.post(
                'https://api.anthropic.com/v1/messages',
                {
                    model: model,
                    max_tokens: 4096,
                    messages: [{ role: 'user', content: prompt }]
                },
                {
                    headers: {
                        'x-api-key': apiKey,
                        'Content-Type': 'application/json',
                        'anthropic-version': '2023-06-01'
                    }
                }
            );
            return response.data.content[0].text;
        }
    },
    google: {
        name: 'Google Gemini',
        call: async (model, prompt, apiKey) => {
            const response = await axios.post(
                `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
                {
                    contents: [{ parts: [{ text: prompt }] }]
                }
            );
            return response.data.candidates[0].content.parts[0].text;
        }
    },
    deepseek: {
        name: 'DeepSeek',
        call: async (model, prompt, apiKey) => {
            const response = await axios.post(
                'https://api.deepseek.com/chat/completions',
                {
                    model: model,
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.7
                },
                {
                    headers: {
                        'Authorization': `Bearer ${apiKey || DEEPSEEK_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            return response.data.choices[0].message.content;
        }
    }
};

// ==========================================
// 任务执行管理器
// ==========================================
const taskExecutions = {};

// ==========================================
// 中间件配置
// ==========================================
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ==========================================
// API 接口区域
// ==========================================

// --- 获取AI服务商列表 ---
app.get('/api/providers', (req, res) => {
    const providers = [
        {
            id: 'openai',
            name: 'OpenAI',
            logo: 'OpenAI',
            models: [
                { id: 'gpt-4o', name: 'GPT-4o', type: 'text' },
                { id: 'gpt-4o-vision-preview', name: 'GPT-4 Vision', type: 'vision' }
            ]
        },
        {
            id: 'anthropic',
            name: 'Anthropic',
            logo: 'Claude',
            models: [
                { id: 'claude-3-sonnet-20240229', name: 'Claude 3 Sonnet', type: 'text' },
                { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus', type: 'vision' }
            ]
        },
        {
            id: 'google',
            name: 'Google Gemini',
            logo: 'Gemini',
            models: [
                { id: 'gemini-pro', name: 'Gemini Pro', type: 'text' },
                { id: 'gemini-pro-vision', name: 'Gemini Pro Vision', type: 'vision' }
            ]
        },
        {
            id: 'deepseek',
            name: 'DeepSeek',
            logo: 'DeepSeek',
            models: [
                { id: 'deepseek-chat', name: 'DeepSeek Chat', type: 'text' },
                { id: 'deepseek-coder', name: 'DeepSeek Coder', type: 'code' }
            ]
        }
    ];
    res.json({ code: 200, message: "获取成功", data: providers });
});

// --- 保存API密钥 ---
app.post('/api/config/keys', (req, res) => {
    const { provider, apiKey, enabled } = req.body;
    const keysData = readJsonFile(API_KEYS_FILE, { api_keys: {} });

    if (keysData.api_keys[provider]) {
        keysData.api_keys[provider].apiKey = apiKey;
        keysData.api_keys[provider].enabled = enabled !== undefined ? enabled : true;
    }

    saveJsonFile(API_KEYS_FILE, keysData);
    res.json({ code: 200, message: 'API密钥保存成功' });
});

// --- 获取API配置 ---
app.get('/api/config/keys', (req, res) => {
    const keysData = readJsonFile(API_KEYS_FILE, { api_keys: {} });
    const status = {};

    Object.keys(keysData.api_keys).forEach(provider => {
        const providerData = keysData.api_keys[provider];
        status[provider] = {
            enabled: providerData.enabled || false,
            configured: !!providerData.apiKey
        };
    });

    res.json({ code: 200, message: "获取成功", data: status });
});

// --- 测试API连接 ---
app.post('/api/config/test', async (req, res) => {
    const { provider, apiKey } = req.body;
    const adapter = AI_PROVIDERS[provider];

    if (!adapter) {
        return res.json({ code: 400, message: '不支持的服务商' });
    }

    try {
        const model = Object.keys(adapter).includes('call') ?
            Object.keys(AI_PROVIDERS).find(k => AI_PROVIDERS[k].name === provider) ?
                'gpt-4o' : 'deepseek-chat' : 'deepseek-chat';

        const result = await adapter.call(model, '测试连接', apiKey);
        res.json({ code: 200, message: '连接成功', result: result });
    } catch (error) {
        res.json({ code: 500, message: '连接失败: ' + error.message });
    }
});

// --- 提交新任务 (DeepSeek拆解) ---
app.post('/api/tasks/submit', async (req, res) => {
    const { demand, aiTypes } = req.body;
    console.log("📥 收到任务需求:", demand);
    console.log("🏷️ 选择的AI类型:", aiTypes);

    try {
        const prompt = `用户在AI协作市场发布了一个新任务，AI协作市场会将任务拆解成几个不同的部分，交由不同类型的AI来完成，例如视觉、图像、语言、文字、声音等等。这个设计旨在让没有接触过AI的普通用户也能很好的利用AI完成他们自己的任务。

任务需求：${demand}
选择的AI类型：${Array.isArray(aiTypes) ? aiTypes.join('、') : '未选择'}

请作为AI助手，将这个需求拆分成几个子任务。对于每个子任务，你需要：
1. 确定子任务的类型（视觉、文字、语言、图像、音频、视频、数据分析）
2. 选择最适合该类型的 AI 服务商
3. 为该服务商选择合适的模型
4. 编写 50 字左右的提示词，明确描述该子任务需要完成什么

请以 JSON 格式返回结果，格式如下（不要添加任何其他文字，只返回纯 JSON）：
{
  "subtasks": [
    {
      "type": "视觉",
      "aiProvider": "openai",
      "aiModel": "gpt-4o-vision-preview",
      "prompt": "设计一张产品宣传海报，要求包含产品图片、品牌logo、宣传标语"
    },
    {
      "type": "文字",
      "aiProvider": "openai",
      "aiModel": "gpt-4o",
      "prompt": "撰写吸引人的产品宣传文案，突出产品特点和优势"
    }
  ]
}`;

        console.log("🤖 正在连接 DeepSeek 思考中...");
        const deepseekResponse = await axios.post(
            'https://api.deepseek.com/chat/completions',
            {
                model: "deepseek-chat",
                messages: [
                    { role: "system", content: "你是一个乐于助人的AI任务助手。" },
                    { role: "user", content: prompt }
                ],
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const aiSuggestion = deepseekResponse.data.choices[0].message.content;
        console.log("✅ DeepSeek 回复:", aiSuggestion);

        let subtasks = null;
        let aiSuggestionRaw = aiSuggestion;  // 保留原始文本用于显示

        try {
            // 尝试解析 JSON
            const jsonMatch = aiSuggestion.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                const parsedJson = JSON.parse(jsonMatch[0]);
                subtasks = parsedJson.subtasks;
                console.log("📋 解析到结构化子任务:", subtasks);
            } else {
                console.log("⚠️ DeepSeek 未返回 JSON 格式，使用默认解析");
                // 如果没有 JSON，使用默认解析逻辑（保留原有逻辑）
                subtasks = parseSubtasksFallback(aiSuggestion, aiTypes);
            }

            // 根据 AI 评分智能分配最佳提供商
            subtasks = assignBestProviderByScore(subtasks);
            console.log("🎯 按评分分配后的子任务:", subtasks);
        } catch (error) {
            console.error("❌ JSON 解析失败:", error);
            console.log("⚠️ 使用默认解析逻辑");
            subtasks = parseSubtasksFallback(aiSuggestion, aiTypes);
            // 评分分配
            subtasks = assignBestProviderByScore(subtasks);
        }

        res.json({
            code: 200,
            message: "任务提交成功！",
            aiSuggestion: aiSuggestionRaw,  // 原始文本用于显示
            subtasks: subtasks,  // 结构化的子任务数据（已按评分分配）
            demand: demand,
            aiTypes: aiTypes
        });
    } catch (error) {
        console.error("❌ 调用 DeepSeek 失败:", error);
        res.status(500).json({
            code: 500,
            message: "AI思考超时了，请检查Key或网络。"
        });
    }
});

// --- 执行子任务 (并行调用多个AI) ---
app.post('/api/tasks/execute', async (req, res) => {
    const { taskId, subtasks } = req.body;
    console.log("🚀 开始执行任务:", taskId);
    console.log("📋 子任务列表:", JSON.stringify(subtasks, null, 2));

    try {
        const keysData = readJsonFile(API_KEYS_FILE, { api_keys: {} });
        console.log("🔑 API密钥配置:", Object.keys(keysData.api_keys || {}));

        taskExecutions[taskId] = {
            status: 'processing',
            startTime: Date.now(),
            subtasks: subtasks.map(st => ({
                ...st,
                status: 'pending',
                result: null,
                error: null
            }))
        };

        // 并行执行所有子任务
        const executionPromises = subtasks.map(async (subtask, index) => {
            const adapter = AI_PROVIDERS[subtask.aiProvider];
            const apiKey = keysData.api_keys[subtask.aiProvider]?.apiKey ||
                          (subtask.aiProvider === 'deepseek' ? DEEPSEEK_API_KEY : null);

            console.log(`🔧 执行子任务 ${index}:`, {
                type: subtask.type,
                aiProvider: subtask.aiProvider,
                aiModel: subtask.aiModel,
                prompt: subtask.prompt?.substring(0, 100),
                hasApiKey: !!apiKey,
                apiKeyPrefix: apiKey ? apiKey.substring(0, 8) + '...' : 'null'
            });

            if (!adapter) {
                throw new Error(`未配置 ${subtask.aiProvider} 的API适配器`);
            }

            if (!apiKey) {
                throw new Error(`未找到 ${subtask.aiProvider} 的API密钥`);
            }

            const startTime = Date.now();
            try {
                console.log(`📤 调用 ${subtask.aiProvider} API...`);
                const result = await adapter.call(subtask.aiModel, subtask.prompt, apiKey);
                const executionTime = Date.now() - startTime;

                console.log(`✅ 子任务 ${index} 完成, 耗时 ${executionTime}ms`);

                taskExecutions[taskId].subtasks[index] = {
                    ...subtask,
                    status: 'completed',
                    result: result,
                    executionTime: executionTime
                };
            } catch (error) {
                console.error(`❌ 子任务 ${index} 失败:`, error.message);
                if (error.response) {
                    console.error(`   响应状态: ${error.response.status}`);
                    console.error(`   响应数据:`, error.response.data);
                }

                taskExecutions[taskId].subtasks[index] = {
                    ...subtask,
                    status: 'failed',
                    error: error.message
                };
            }
        });

        await Promise.allSettled(executionPromises);

        taskExecutions[taskId].status = 'completed';
        taskExecutions[taskId].endTime = Date.now();

        res.json({
            code: 200,
            message: "任务执行成功",
            taskId: taskId
        });
    } catch (error) {
        console.error("❌ 任务执行失败:", error);
        res.status(500).json({
            code: 500,
            message: "任务执行失败: " + error.message
        });
    }
});

// --- 查询任务执行状态 ---
app.get('/api/tasks/status', (req, res) => {
    const { taskId } = req.query;
    const execution = taskExecutions[taskId];

    if (!execution) {
        return res.json({ code: 404, message: '任务不存在' });
    }

    res.json({
        code: 200,
        data: execution
    });
});

// --- 获取任务列表 (原功能保留) ---
app.get('/api/tasks/list', (req, res) => {
    const MOCK_DATA = {
        tasks: [
            { id: 101, title: "LLM 模型微调优化", priority: "高", status: "待处理", owner: "Dr. Neural", deadline: "2026-02-07" },
            { id: 102, title: "Diffusion 模型效果迭代", priority: "中", status: "进行中", owner: "PixelMind", deadline: "2026-02-15" },
            { id: 103, title: "PyTorch 环境部署优化", priority: "低", status: "已完成", owner: "CodeFlow", deadline: "2026-02-01" }
        ]
    };
    res.json({ code: 200, message: "获取成功", data: MOCK_DATA.tasks });
});

// --- 获取排行榜数据 ---
app.get('/api/rank/all', (req, res) => {
    const MOCK_DATA = {
        developers: [
            { rank: 1, name: "Dr. Neural", points: 12840 },
            { rank: 2, name: "PixelMind", points: 11200 },
            { rank: 3, name: "CodeFlow", points: 9850 }
        ],
        skills: [
            { rank: 1, name: "Vision-Pro-X v3.2", rating: 5.0 },
            { rank: 2, name: "Gen-Audio-v2.1", rating: 4.0 }
        ]
    };
    res.json({ code: 200, message: "获取成功", data: MOCK_DATA });
});

// --- 提交AI评分 ---
app.post('/api/ratings/submit', (req, res) => {
    const { ratings } = req.body;
    console.log("📊 收到评分数据:", ratings);

    try {
        const scoresData = readJsonFile(SCORES_FILE, { ai_scores: [] });

        ratings.forEach(rating => {
            let existingAi = scoresData.ai_scores.find(ai => ai.name === rating.name);

            if (existingAi) {
                existingAi.totalScore += rating.score;
                existingAi.ratingCount += 1;
                existingAi.avgScore = (existingAi.totalScore / existingAi.ratingCount).toFixed(1);
                existingAi.usageCount += 1;
                existingAi.responseTime = rating.responseTime || existingAi.responseTime;
            } else {
                const iconMap = {
                    '视觉': 'eye-solid',
                    '文字': 'document-text-solid',
                    '语言': 'chat-bubble-left-solid',
                    '图像': 'photo-solid',
                    '音频': 'mic-solid',
                    '视频': 'video-camera-solid',
                    '数据分析': 'chart-bar-solid'
                };
                scoresData.ai_scores.push({
                    id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                    name: rating.name,
                    type: rating.type,
                    icon: iconMap[rating.type] || 'sparkles-solid',
                    totalScore: rating.score,
                    ratingCount: 1,
                    avgScore: rating.score.toFixed(1),
                    responseTime: rating.responseTime || '未知',
                    usageCount: 1
                });
            }
        });

        saveJsonFile(SCORES_FILE, scoresData);
        console.log("✅ 评分保存成功！");

        res.json({ code: 200, message: "评分提交成功！" });
    } catch (error) {
        console.error("❌ 保存评分失败:", error);
        res.status(500).json({ code: 500, message: "保存评分失败" });
    }
});

// --- 获取AI排行榜 (动态数据) ---
app.get('/api/rank/ai', (req, res) => {
    const scoresData = readJsonFile(SCORES_FILE, { ai_scores: [] });
    const sortedAi = scoresData.ai_scores.sort((a, b) => b.avgScore - a.avgScore);

    res.json({ code: 200, message: "获取成功", data: sortedAi });
});

// ==========================================
// 启动服务器
// ==========================================
app.listen(PORT, () => {
    console.log('\n🚀 服务已启动！');
    console.log(`👉 请在浏览器打开: http://localhost:${PORT}/index.html`);
    console.log('\n📁 可用页面：');
    console.log(`   - 首页: http://localhost:${PORT}/index.html`);
    console.log(`   - 技能广场: http://localhost:${PORT}/skill.html`);
    console.log(`   - 任务中心: http://localhost:${PORT}/task.html`);
    console.log(`   - API配置: http://localhost:${PORT}/config.html`);
    console.log(`   - 任务执行: http://localhost:${PORT}/execute.html`);
    console.log(`   - 排行榜: http://localhost:${PORT}/rank.html`);
    console.log('\n💾 数据库位置:');
    console.log(`   - API密钥: ${API_KEYS_FILE}`);
    console.log(`   - AI评分: ${SCORES_FILE}`);
});
