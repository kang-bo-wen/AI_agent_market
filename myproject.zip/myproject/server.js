	// ==========================================
	// 1. 引入必要的包
	// ==========================================
	const express = require('express');
	const cors = require('cors');
	const bodyParser = require('body-parser');
	const path = require('path');
	const axios = require('axios'); // 专门用来发请求的工具
	const app = express();
	const PORT = 3000;
	// ==========================================
	// 【重要】在这里填入你的 DeepSeek API Key
	// ==========================================
	const DEEPSEEK_API_KEY = "sk-aa2e775113174aacadc873c81e732f8f"; // <-- 把这里替换成你的 Key
	// ==========================================
	// 2. 基础配置
	// ==========================================
	app.use(cors()); // 允许跨域
	app.use(bodyParser.json()); // 解析 JSON 格式的数据
	app.use(express.static('public')); // 加载 public 文件夹下的 HTML
	// ==========================================
	// 3. 模拟数据库 (保持其他页面的数据正常显示)
	// ==========================================
	const MOCK_DATA = {
	    tasks: [
	        { id: 101, title: "LLM 模型微调优化", priority: "高", status: "待处理", owner: "Dr. Neural", deadline: "2026-02-07" },
	        { id: 102, title: "Diffusion 模型效果迭代", priority: "中", status: "进行中", owner: "PixelMind", deadline: "2026-02-15" },
	        { id: 103, title: "PyTorch 环境部署优化", priority: "低", status: "已完成", owner: "CodeFlow", deadline: "2026-02-01" }
	    ],
	    ranks: {
	        developers: [
	            { rank: 1, name: "Dr. Neural", points: 12840 },
	            { rank: 2, name: "PixelMind", points: 11200 },
	            { rank: 3, name: "CodeFlow", points: 9850 }
	        ],
	        skills: [
	            { rank: 1, name: "Vision-Pro-X v3.2", rating: 5.0 },
	            { rank: 2, name: "Gen-Audio-v2.1", rating: 4.0 }
	        ]
	    }
	};
	// ==========================================
	// 4. API 接口区域
	// ==========================================
	// --- 接口 A: 获取任务列表 (保持不变，用于前端列表展示) ---
	app.get('/api/tasks/list', (req, res) => {
	    res.json({
	        code: 200,
	        message: "获取成功",
	        data: MOCK_DATA.tasks
	    });
	});
	// --- 接口 B: 提交新任务 (接入了 DeepSeek) ---
	app.post('/api/tasks/submit', async (req, res) => {
	    const { demand, aiTypes } = req.body;
	    console.log("------------------------------------------------");
	    console.log("📥 收到任务需求:", demand);
	    console.log("🏷️  选择的AI类型:", aiTypes);
	    console.log("------------------------------------------------");
	    try {
	        // 1. 构造发给 DeepSeek 的提示词
	        const prompt = `用户在AI协作市场发布了一个新任务， AI协作市场会将任务拆解成几个不同的部分，交由不同类型的AI来完成，例如视觉，图像，语言，文字，声音等等。这个设计旨在让没有接触过AI的普通用户也能很好的利用AI完成他们自己的任务。
	        任务需求：${demand}
	        选择的AI类型：${aiTypes.join('、')}
	        请作为AI助手，将这个需求拆分成几个子任务，并且给出每个子任务适合的AI类型及列出一个具体的AI（包含deepseek你自己也可以哦）和建议给该AI的提示词（50字左右）。你的回答将作为解决问题的重要参考，稍后会提取你回答的内容并调用相应的AI来执行。`;
	        // 2. 调用 DeepSeek API
	        console.log("🤖 正在连接 DeepSeek 思考中...");
	        const deepseekResponse = await axios.post(
	            'https://api.deepseek.com/chat/completions',
	            {
	                model: "deepseek-chat",
	                messages: [
	                    { role: "system", content: "你是一个乐于助人的AI任务助手。" },
	                    { role: "user", content: prompt }
	                ],
	                temperature: 0.7
	            },
	            {
	                headers: {
	                    'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
	                    'Content-Type': 'application/json'
	                }
	            }
	        );
	        // 3. 获取 AI 的回复内容
	        const aiSuggestion = deepseekResponse.data.choices[0].message.content;
	        console.log("✅ DeepSeek 回复:", aiSuggestion);
	        // 4. 返回结果给前端
	        res.json({
	            code: 200,
	            message: "任务提交成功！",
	            aiSuggestion: aiSuggestion // 把AI的建议传回去
	        });
	    } catch (error) {
	        console.error("❌ 调用 DeepSeek 失败:", error.response ? error.response.data : error.message);
	        res.status(500).json({
	            code: 500,
	            message: "AI思考超时了，请检查Key或网络。"
	        });
	    }
	});
	// --- 接口 C: 获取排行榜数据 (保持不变) ---
	app.get('/api/rank/all', (req, res) => {
	    res.json({
	        code: 200,
	        data: MOCK_DATA.ranks
	    });
	});
	// 5. 启动服务器
	app.listen(PORT, () => {
	    console.log(`\n🚀 服务已启动！`);
	    console.log(`👉 请在浏览器打开: http://localhost:${PORT}/task.html`);
	});